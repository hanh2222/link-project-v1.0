<?php
if($PermissionView !== false){
	if(isset($accessToken)){
		if(isset($password)){
		  echo '<i class="fa fa-check-circle-o" aria-hidden="true"></i> Đã xác nhận mật khẩu thành công!<br/>';
		} else {
		  echo '<form action method="POST">
		<div class="input-group">
		<span class="input-group-addon">Mật khẩu liên kết</span>
		<input type="password" name="password" placeholder="Nhập nhật khẩu bảo vệ" autofocus="off" autocomplete="off" class="form-control">
		<span class="input-group-btn">
		  <button type="submit" class="btn btn-default">Xác nhận</button>
		</span>
		</div>
		</form>
		<i class="fa fa-circle-o" aria-hidden="true"></i> Liên kết này có mật khẩu, vui lòng nhập để xác nhận!<br/>';
		}
		if(isset($liked)){
		  echo '<i class="fa fa-check-circle-o" aria-hidden="true"></i> Đã xác nhận bạn đã like bài viết!<br/>';
		} else {<?php
if($PermissionView !== false){
	if(isset($accessToken)){
		if(isset($password)){
		  echo '<i class="fa fa-check-circle-o" aria-hidden="true"></i> Đã xác nhận mật khẩu thành công!<br/>';
		} else {
		  echo '<form action method="POST">
		<div class="input-group">
		<span class="input-group-addon">Mật khẩu liên kết</span>
		<input type="password" name="password" placeholder="Nhập nhật khẩu bảo vệ" autofocus="off" autocomplete="off" class="form-control">
		<span class="input-group-btn">
		  <button type="submit" class="btn btn-default">Xác nhận</button>
		</span>
		</div>
		</form>
		<i class="fa fa-circle-o" aria-hidden="true"></i> Liên kết này có mật khẩu, vui lòng nhập để xác nhận!<br/>';
		}
		if(isset($liked)){
		  echo '<i class="fa fa-check-circle-o" aria-hidden="true"></i> Đã xác nhận bạn đã like bài viết!<br/>';
		} else {
		  echo '<i class="fa fa-circle-o" aria-hidden="true"></i> Bạn chưa like bài viết! Vui lòng truy cập liên kết trên để like và thử lại!<br/>';
		}
		if(isset($commented)){
		  echo '<i class="fa fa-check-circle-o" aria-hidden="true"></i> Đã xác nhận bạn đã bình luận bài viết!<br/>';
		} else {
		  echo '<i class="fa fa-circle-o" aria-hidden="true"></i> Bạn chưa bình luận bài viết! Truy cập liên kết trên để bình luận và thử lại.<br/>';
		}
		if(isset($joined)){
		  echo '<i class="fa fa-check-circle-o" aria-hidden="true"></i> Đã xác nhận bạn là thành viên của group!<br/>';
		} else {
		$PostVerifyGraph = 'https://graph.facebook.com/'.$PostIDVerified.'?fields=id,permalink_url,message&access_token='.$accessToken;
		$PostVerify = json_decode(file_get_contents($PostVerifyGraph, true)); //user info

		//Comments Api
		$CmtApi = 'https://graph.facebook.com/v2.10/'.$PostVerify->id.'/comments?fields=message,id,from,can_comment&limit=5000&access_token='.$accessToken;
		$CmtVerify = json_decode(file_get_contents($CmtApi));

		//Check hashtag exists 
		foreach($CmtVerify->data as $cmt){
			if($cmt->message == '#verify@'.$UserHashVerify.'@'){
				$verified = true;
				if($cmt->can_comment != 1){
				$verified = false;
			  }
			}
		  }

		if(isset($verified)){
		  if($verified == true){
			echo '<i class="fa fa-check-circle-o" aria-hidden="true"></i> Đã xác nhận bạn là thành viên của group!<br/>';
		  } elseif($verified == false) {
			echo '<i class="fa fa-circle-o" aria-hidden="true"></i> Bạn chưa tham gia group. Vui lòng tham gia group và thử lại. [Đây là nhầm lẫn? Hãy thử <a href="/verify/'.$GroupID.'" target="_blank">xác nhận thành viên</a>]<br/>';
		  }
		} elseif($PostIDVerify == null){
			echo '<i class="fa fa-circle-o" aria-hidden="true"></i> Bạn chưa tham gia group. Vui lòng tham gia group và thử lại.<br/>';
		  } else {
			  echo '<i class="fa fa-circle-o" aria-hidden="true"></i> Bạn chưa tham gia group. Vui lòng tham gia group và thử lại. [Đây là nhầm lẫn? Hãy thử <a href="/verify/'.$GroupID.'" target="_blank">xác nhận thành viên</a>]<br/>'.$PostVerifyGraph;
		  }
		}
	}
}
?>
<hr style="margin-top:10px;margin-bottom:10px">
<small>Phát triển bởi <a href="https://www.facebook.com/NghiaisGay">Vy Nghĩa</a>
<br/>&copy; 2017 Vy Nghĩa - bản quyền phát triển hợp lệ.</small>
</div>
</div>
<!-- Suggest Content -->
<div class="portlet">
<div class="portlet-header">
<h3>
<i class="fa fa-star-o"></i>
Đề xuất
</h3>
<style>
.tags {
  list-style: none;
  margin: 0;
  overflow: hidden; 
  padding: 0;
  font-size: 12px;
  margin: 15px 15px 5px 15px;
  text-decoration: none;
}

.tags li {
  float: left; 
}

.tag {
  background: #eee;
  border-radius: 3px 0 0 3px;
  color: #999;
  display: inline-block;
  height: 26px;
  line-height: 26px;
  padding: 0 20px 0 23px;
  position: relative;
  margin: 0 10px 10px 0;
  text-decoration: none;
  -webkit-transition: color 0.2s;
}

.tag::before {
  background: #fff;
  border-radius: 10px;
  box-shadow: inset 0 1px rgba(0, 0, 0, 0.25);
  content: '';
  height: 6px;
  left: 10px;
  position: absolute;
  width: 6px;
  top: 10px;
}

.tag::after {
  background: #fff;
  border-bottom: 13px solid transparent;
  border-left: 10px solid #eee;
  border-top: 13px solid transparent;
  content: '';
  position: absolute;
  right: 0;
  top: 0;
}

.tag:hover {
  text-decoration: none;
  background-color: #DDDDDD;
  color: black;
}

.tag:hover::after {
   border-left-color: #DDDDDD;
}
</style>

</div> 
<!-- Tags Area +/Suggest Content -->
<div class="portlet-content" style="margin:0;padding:0">
<ul class="tags">
  <li><a href="https://www.facebook.com/j2tea.pro?ref=emelja" class="tag">j2team</a></li>
  <li><a href="https://www.facebook.com/groups/j2team.community/?ref=emelja" class="tag">j2team community</a></li>
  <li><a href="https://www.facebook.com/NghiaisGay/?ref=emelja" class="tag">vy nghĩa</a></li>
  <li><a href="http://www.khari-nnt.com/" class="tag">nguyễn khải blog</a></li>
</ul>
</div> 

</div>
</div></div></div>
  

<!-- [S] Footer -->
<div id="footer" class="footer">
  <div class="container">
    <div class="col-sm-12">
      <div class="inner" style="margin-left: auto; margin-right: auto;">
        <div class="statistic" style="color:#333;line-height:20px;">
          <h6>Thông tin</h6>
          <div class="box">
            IP của bạn là: <?php echo $_SERVER['REMOTE_ADDR']; ?><br>
            Email liên hệ : contact@<?php echo $_SERVER['HTTP_HOST']; ?><br>
            <i class="fa fa-lock" aria-hidden="true"></i> Security by BαWorld Team
          </div>
        </div>
        <div class="sinhvienit">
          <h6>Liên kết</h6>
          <a href="https://domain.com" title="Domain title" target="_blank">domain</a>
        </div>
        <hr class="clear">
      </div>
    </div>
  </div>
</div>
<!-- [E] Footer -->
</body>
</html>
		  echo '<i class="fa fa-circle-o" aria-hidden="true"></i> Bạn chưa like bài viết! Vui lòng truy cập liên kết trên để like và thử lại!<br/>';
		}
		if(isset($commented)){
		  echo '<i class="fa fa-check-circle-o" aria-hidden="true"></i> Đã xác nhận bạn đã bình luận bài viết!<br/>';
		} else {
		  echo '<i class="fa fa-circle-o" aria-hidden="true"></i> Bạn chưa bình luận bài viết! Truy cập liên kết trên để bình luận và thử lại.<br/>';
		}
		if(isset($joined)){
		  echo '<i class="fa fa-check-circle-o" aria-hidden="true"></i> Đã xác nhận bạn là thành viên của group!<br/>';
		} else {
		$PostVerifyGraph = 'https://graph.facebook.com/'.$PostIDVerified.'?fields=id,permalink_url,message&access_token='.$accessToken;
		$PostVerify = json_decode(file_get_contents($PostVerifyGraph, true)); //user info

		//Comments Api
		$CmtApi = 'https://graph.facebook.com/v2.10/'.$PostVerify->id.'/comments?fields=message,id,from,can_comment&limit=5000&access_token='.$accessToken;
		$CmtVerify = json_decode(file_get_contents($CmtApi));

		//Check hashtag exists 
		foreach($CmtVerify->data as $cmt){
			if($cmt->message == '#verify@'.$UserHashVerify.'@'){
				$verified = true;
				if($cmt->can_comment != 1){
				$verified = false;
			  }
			}
		  }

		if(isset($verified)){
		  if($verified == true){
			echo '<i class="fa fa-check-circle-o" aria-hidden="true"></i> Đã xác nhận bạn là thành viên của group!<br/>';
		  } elseif($verified == false) {
			echo '<i class="fa fa-circle-o" aria-hidden="true"></i> Bạn chưa tham gia group. Vui lòng tham gia group và thử lại. [Đây là nhầm lẫn? Hãy thử <a href="/verify/'.$GroupID.'" target="_blank">xác nhận thành viên</a>]<br/>';
		  }
		} elseif($PostIDVerify == null){
			echo '<i class="fa fa-circle-o" aria-hidden="true"></i> Bạn chưa tham gia group. Vui lòng tham gia group và thử lại.<br/>';
		  } else {
			  echo '<i class="fa fa-circle-o" aria-hidden="true"></i> Bạn chưa tham gia group. Vui lòng tham gia group và thử lại. [Đây là nhầm lẫn? Hãy thử <a href="/verify/'.$GroupID.'" target="_blank">xác nhận thành viên</a>]<br/>'.$PostVerifyGraph;
		  }
		}
	}
}
?>