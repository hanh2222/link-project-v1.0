<?php
/* >_ Developed by Vy Nghia */
require_once '../login.php';
$idhashtag = $_POST['id'];
mysql_query("DELETE FROM `protect` WHERE `id` = '$idhashtag'");