<?php
/* >_ Developed by Vy Nghia */
require_once '../server/config.php';
require_once '../login.php';
#Hash & Link
$ConditonNumber = rand(1,2);
$hash1 = rand(100, 1000);
$hash2 = rand(1, 1000);
$hash3 = rand(1, 1000);

//Text radnom Generator
function _u31ato($i = 1) {
	return substr(str_shuffle(str_repeat($x='xsz', ceil($i/strlen($x)) )),1,$i);
}
$StrHash1 = _u31ato();
if($ConditonNumber == 1){
function _x3w5sj($i = 1) {
	return substr(str_shuffle(str_repeat($x='xsz', ceil($i/strlen($x)) )),1,$i);
}
$StrHash2 = _x3w5sj();
}

$TargetID = $groupids;
$SaveMode = $_POST['SaveMode'];
$MainURL = $_POST['url'];
$like= $_REQUEST['like'];
$comment= $_REQUEST['comment'];
$join = $_REQUEST['join'];

$HashURL = $hash1.$StrHash1.$hash2.$StrHash2.$hash3;
$Hashtag = $HashURL;

$DomainShortURL = $domain.'/v/'.$HashURL; //Domain short url

$Password = $_POST['password']; //Set Password

# TimeZone/Time
date_default_timezone_set('Asia/Ho_Chi_Minh'); //TimeZone VietNam
$time = date("Y-m-d h:i:s"); //Time type

if(isset($MainURL)&&!empty($MainURL)){
function make_bitly_url($url, $login, $appkey, $format='json', $history=1, $version='2.0.1')
{
	//create the URL
	$bitly = 'http://api.bit.ly/shorten';
	$param = 'version='.$version.'&longUrl='.urlencode($url).'&login='
		.$login.'&apiKey='.$appkey.'&format='.$format.'&history='.$history;
		$url = "$bitly?$param";

    $curl = curl_init();
   curl_setopt_array($curl, array(
      CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $data = json_decode($response,JSON_UNESCAPED_UNICODE);
    $datas = $data["results"];
    foreach($datas as $results){
       return $results['shortUrl'];
    }
}
$longUrl = $DomainShortURL;
$GoogleShortUrl = make_bitly_url($longUrl,$bitlylogin,$bitlyapikey);
//Print result
echo '<div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Kết quả </h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>

                           
                        </div>
                    </div>
                    <div class="ibox-content" id="results">
                    <div class="alert alert-info" style="color:blue" role="alert">
                        <strong>*Lưu ý:</strong><br>
                        
                        - Copy cả link và hashtag để đăng bài.<br>
                        - Khi đã đăng bài xong . Vui lòng chờ trong vòng 5 phút.<br>
                        - Nếu trong vòng 5 phút nếu chưa kích hoạt, vui lòng vào trang ẩn link của bạn để kích hoạt <br>
                            
                    
                </div>


                    <label for="link-and-hash">Link khóa kèm hashtag (copy toàn bộ vào bài đăng nhé):</label><br>
                    <div class="input-group">
                        <input id="short-url" class="form-control" value="'.$DomainShortURL.' | #protect@'.$Hashtag.'@" readonly=""><br>
                        <span class="input-group-btn">
                            <button id="generator-url" data-clipboard-target="#short-url" data-clipboard-target="#short-url" class="btn btn-info btn-fill">Sao Chép</button>';

#Insert data url into SQL
mysql_query("INSERT INTO `protect`(`id`, `facebook_user_id`, `group_id`,`post_id`, `hash`, `url`, `short_url`, `password`, `like`, `comment`, `joined`, `time`) VALUES ('','$idreals', '$TargetID', '', '$HashURL', '$MainURL', '$GoogleShortUrl', '$Password', '$like', '$comment', '$join', '$time')");
}

