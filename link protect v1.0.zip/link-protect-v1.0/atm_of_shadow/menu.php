
                    <li  <?php if($_SERVER['PHP_SELF']== "/index.php") { echo  'class="active"';} else { echo '' ;} ?>>
                        <a href="/index.php"><i class="fa fa-home"></i> <span class="nav-label">Trang Chủ</span></a>
                        
                    <?php if(!empty($administrator or $moderator)){ ?> <li <?php if($_SERVER['PHP_SELF']== "/install.php") { echo  'class="active"';} else { echo '' ;} ?> >
                        <a href="/install.php"><i class="fa fa-user-o"></i> <span class="nav-label">Cấu Hình Máy Chủ</span></a> <?php } else {   echo '';} ?>
                    </li>
                    <?php if(!empty($administrator or $moderator)){ ?> 
                    <li <?php if($_SERVER['PHP_SELF']== "/ebook.php") { echo  'class="active"';} else { echo '' ;} ?>>
                        <a href="/ebook.php"><i class="fa fa-address-book"></i> <span class="nav-label">EBOOK</span></a>
                    </li><?php } else {   echo '';} ?>

                    <li <?php if($_SERVER['PHP_SELF']== "/addlink.php") { echo  'class="active"';} else { echo '' ;} ?>>
                        <a href="/addlink.php"><i class="fa fa-plus-square"></i> <span class="nav-label">Ẩn Link TOOL</span></a>
                    </li>
                     <li <?php if($_SERVER['PHP_SELF']== "/fulllink.php") { echo  'class="active"';} else { echo '' ;} ?>>
                    <?php  if(!empty($administrator or $moderator)){ ?>
                    <a href="/fulllink.php"><i class="fa fa-wrench"></i> <span class="nav-label">Quản lý all Link</span></a>
                    <?}?>