<?php
if($token == null){
	echo '<center><a href = "'.$loginUrl.'"><button type="button" class="btn btn-danger" >Đăng nhập</button></a><br/>
	<p>Chỉ lấy quyền cơ bản (<strong>xem ID</strong>, <strong>tên</strong> và <strong>danh sách bạn bè</strong>) của bạn. Không đòi hỏi các quyền nhạy cảm như <strong>đăng bài</strong>, <strong>like</strong> và <strong>chia sẻ</strong>.</p></center>';
}

//After login => access_token
	if(!empty($token)){
	$BannedUser = mysql_query("SELECT * FROM `blacklist` WHERE `user_id` = '$userID'"); //Check user exists in SQL
	
	//User banned alert
    if(mysql_fetch_array($BannedUser) == true){
		echo '<li id="error" class="list-group-item"><center><br/><br/><p style="font-size: 18">Đã có lỗi xảy ra, bạn không thể xem liên kết !</p><br/><br/></center></li>';
		$PermissionView = false;
		exit;
	}
	$ProfileApi = 'https://graph.facebook.com/'.$idreals.'?access_token='.$token;
	$GroupInfo = 'https://graph.facebook.com/'.$GroupID.'?fields=name,id&access_token='.$token;

	//JSON decode
	$Group = json_decode(file_get_contents($ProfileApi, true)); //page info
	$user = json_decode(file_get_contents($ProfileApi, true)); //user info

	//Feed (timeline) data
	$FeedApi = file_get_contents('https://graph.facebook.com/'.$GroupID.'/feed?limit=100&access_token='.$token);
	$FeedJson = json_decode($FeedApi, true);

	//Get Facebook user_id
	$userID = $user->id;

	if($_POST['password'] == $ProtectPassword){
		$password = true;
	}

	//Search member joined group
	$MemberApi = 'https://graph.facebook.com/fql?q=SELECT%20uid%20FROM%20group_member%20WHERE%20gid='.$GroupID.'%20AND%20uid='.$idreals.'&access_token='.$token;
	$MemberApi_decode = json_decode(file_get_contents($MemberApi));
	foreach($MemberApi_decode->data as $member){
		if($member->uid == $userID){
	        $joined = true;
	    }
	}
	
	//Find post_id
	foreach($FeedJson["data"] as $feed) {
    if(strpos($feed['message'], $hashtag) !== FALSE) {
		$FoundPost = true;
		$FoundPostID = str_replace($GroupID.'_', '',$feed['id']);
	

		//Get info Post
		$PostApi = 'https://graph.facebook.com/v2.10/'.$FoundPostID.'?fields=id,permalink_url,message&access_token='.$token;
		$PostGroup = json_decode(file_get_contents($PostApi));
		//Search user reactions ID 
		$LikeApi = 'https://graph.facebook.com/v2.10/'.$PostGroup->id.'/reactions?fields=id&pretty=0&live_filter=no_filter&limit=5000&access_token='.$token;
		$LikeApi_decode = json_decode(file_get_contents($LikeApi));
		foreach($LikeApi_decode->data as $like){
	    if($like->id == $userID){
	        $liked = true;
	    	}
		}
	    if($likeds == null){
	        $liked = true;
	    	}
		
		//Search user comments
		$CmtApi = 'https://graph.facebook.com/v2.10/'.$PostGroup->id.'/comments?fields=from,id&limit=5000&access_token='.$token;
		$CmtApi_decode = json_decode(file_get_contents($CmtApi));
		foreach($CmtApi_decode->data as $cmt){
	    if($cmt->from->id == $userID){
	        $commented = true;
	    	}
		}
		if($commenteds == null){
	        $commented = true;
	    	}
		// scan count like & cmt
		$searchpost = "https://graph.facebook.com/v2.10/".$PostGroup->id."?fields=shares,reactions.summary(true),comments.summary(true)&access_token=".$token.""; 
		$likecmtcount = json_decode(file_get_contents($searchpost, true)); 
		$solike = $likecmtcount->reactions->summary->total_count;
		$socmt = $likecmtcount->comments->count;

		if(!empty($liked&&$commented&&$joined)){
			$MainURL = '<i class="fa fa-angle-right" aria-hidden="true"></i> <a href="'.$url.'">'.$url.'</a> <i class="fa fa-angle-left" aria-hidden="true"></i>';
		}
		
		if("$AuthorID" == $userID){
			$MainURL = '<i class="fa fa-angle-right" aria-hidden="true"></i> <a href="'.$url.'">'.$url.'</a> <i class="fa fa-angle-left" aria-hidden="true"></i><br>Bạn là người tạo ra liên kết nên không cần xác minh để xem liên kết bị ẩn!';
		}
		    // count like && cmt
			if(isset($countlike)){
			$like_id = mysql_query("UPDATE `".$dbname."`.`protect` SET `countlike` = '$solike' WHERE `protect`.`hash` = '$Hash'");
			if (mysql_query($like_id)){
			}
			if(isset($countcmt)){
			$cmt_id = mysql_query("UPDATE `".$dbname."`.`protect` SET `countcmt` = '$socmt' WHERE `protect`.`hash` = '$Hash'");
			if (mysql_query($cmt_id)){
			}
			//Found ID post but not set data into mySQL
			if($PostID == null){
			$found_id = mysql_query("UPDATE `".$dbname."`.`protect` SET `post_id` = '$FoundPostID' WHERE `protect`.`hash` = '$Hash'");
			if (mysql_query($found_id)){
			} else {
				null;
			}
			echo '<li id="get-link" class="list-group-item">
			<center><br/><br/><p style="font-size: 18"><br/>';
			echo $MainURL.'
			</p>
			<br/><br/>
			</center></li><br/>'; //Check like/comment/members or not like/comment/members
			include 'atm_of_shadow/data_url.php';
			exit;
			}
			}
			}
		}
	}
	if(isset($FoundPost)){
	// Found post and have set into mySQL
	echo '
		<center><br/><br/><p style="font-size: 18"><br/>';
		echo $MainURL.'
		</p>
		<br/><br/>
		</center></li><br/>'; //Check like/comment/members or not like/comment/members
	}
	if($PostID == null){
//		echo '<li id="get-link" class="list-group-item"><center><br/><br/><p style="font-size: 18">Chưa có bài viết nào gắn #hashtag cho url này</p><br/><br/></center></li>';
echo '<center><br/><br/><p style="font-size: 18"><br/>';
		echo $MainURL.'<i class="fa fa-angle-right" aria-hidden="true"></i> <a href="'.$url.'">'.$url.'</a> <br/><p style="font-size: 18">Chưa có bài viết nào gắn #hashtag cho url này</p><i class="fa fa-angle-left" aria-hidden="true"></i>
		</p>
		<br/><br/>
		</center></li><br/>';
	}
  }