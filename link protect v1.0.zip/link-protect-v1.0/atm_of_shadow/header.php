<?php
require_once 'login.php';
if($accessToken == null){
    $callback = fopen("logcallback/".$_SERVER['REMOTE_ADDR'].".txt", "w+") or die("Unable to open file!");
    fwrite($callback, $_SERVER['PHP_SELF']);
    fclose($callback);
    echo "<script>location.href='$domain/dangnhap.php'</script>";
}
if(isset($accessToken)){
    $idadmins = mysql_query("SELECT * FROM `admingroup` WHERE `function` = 'admin'");
    $idmods = mysql_query("SELECT * FROM `admingroup` WHERE `function` = 'mod'");
    while($idadmin = mysql_fetch_array($idadmins)){
		if($idadmin['id'] == $idreals){
		    $administrator = true;
	    	}
		}
		while($idmod = mysql_fetch_array($idmods)){
			if($idmod['id'] == $idreals){
			$moderator = true;
			}
		}
		$getuser = mysql_query("SELECT * FROM `user` WHERE `id` = '$userID'");
}
?>
    <!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title><?php echo $groupname ?> - Protect File</title>
    <link rel="shortcut icon" type="image/png" href="/logo.small.png"/>
    <link href="/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="/assets/css/plugins/toastr/toastr.min.css" rel="stylesheet">
    <link href="http://kouki.website/vendor/koukicons/koukicons.min.css" rel="stylesheet">


    <!-- Gritter -->
    <link href="/assets/css/plugins/gritter/jquery.gritter.css" rel="stylesheet">
    <link href="/assets/css/plugins/summernote/summernote.css" rel="stylesheet">
    <link href="/assets/css/plugins/summernote/summernote-bs3.css" rel="stylesheet">
    <link href="/assets/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="/assets/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">
    <link href="/assets/css/animate.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.4/sweetalert2.css" rel="stylesheet" type="text/css">
<style>
textarea {
     width: 100%;
	 height: 100px;
	 resize: none;
     -webkit-box-sizing: border-box; /* Safari/Chrome, other WebKit */
     -moz-box-sizing: border-box;    /* Firefox, other Gecko */
     box-sizing: border-box;         /* Opera/IE 8+ */
}
</style>
</head>

<body>
    <?php if($_SERVER['PHP_SELF']== "/url.php") { echo '';} else { echo '<body class="boxed-layout fixed-sidebar"> <!--- muốn menu vào lề trái xóa dòng này  -->' ;}?>
    
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="https://graph.facebook.com/<?=$idreals?>/picture?width=128"height="65" />
                             </span>

                            <span class="clear"><?php if(!empty($administrator or $moderator)){ echo '<span class="fa fa-user fa-1x text-muted text-xs block">  <strong class="font-bold">BQT GROUP </strong></span><span class="text-muted text-xs block">  <strong class="font-bold">=>'.$name.' <=</strong></span>'; } else {   echo '<span class="block m-t-xs">  <strong class="font-bold">'.$name.'</strong></span>';} ?><?php if(!empty($administrator or $moderator)){ echo '</strong></span> <span  class="fa fa-star fa-1x text-muted text-xs block" > </span>';} else { }    ?></span> 

                        </div>
                        <div class="logo-element">
                            <img alt="image" class="img-circle" src="/logo.small.png" height="50">
                        </div>
                    </li>
