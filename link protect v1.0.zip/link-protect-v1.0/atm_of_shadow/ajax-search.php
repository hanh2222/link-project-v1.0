<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
header('Content-Type: text/html; charset=utf-8');
/***********************************
 * Tác giả: 2Cwebvn
 * Website : www.2cweb.vn
 ***********************************/
mysqli_close($con);
//  Include file kết nối Database
include_once ('../server/config.php');			

// Kiểm tra dữ liệu đầu vào có tồn tại hay không
if(isset($_GET['keyword'])){		
    $keyword = 	trim($_GET['keyword']) ;		// Cắt bỏ khoảng trắng
	$keyword = mysqli_real_escape_string($dbc, $keyword);	// Lọc các ký tự đặc biệt

	// Câu query lấy dữ liệu
	$query = "SELECT *  from postgroup where message like '%$keyword%' limit 20";

	// Kết nối Database, thực hiện câu truy vấn
	$result = mysql_query($query);

	// Kiểm tra kết quả trả về có hay không ?
	if($result){
		// Kiểm tra có dòng record nào hay không?
		if(mysql_affected_rows()!=0){  
			// Hiển thị dữ liệu
			while($row = mysql_fetch_array($result)){?>
<meta http-equiv="content-type" content="text/html; charset=utf-8"><div class="hr-line-dashed"></div>
                            <div class="hr-line-dashed"></div>
                            <div class="search-result">
                                  <div class="media">
                                          <div class="media-left">
                                            <a href="https://www.facebook.com/profile.php?id=<?php echo $row['id_author'] ?>" target="_blank">
                                              <img class="img-circle circle-border m-b-md" height="64" width="64" src="https://graph.facebook.com/<?php echo $row['id_author'] ?>/picture?width=64" alt="<?php echo $row['name'] ?>">
                                            </a>
                                          </div>
                                          <div class="media-body">
                                              <h3 class="media-heading">
                                                <a href="https://www.facebook.com/<?php echo $row['id_author'] ?>" target="_blank"><?php echo $row['name'] ?></a>
                                              </h3><div style="font-size: 16px;"><?php echo $row['message'] ?></div><br><br>
                                              </h3><a target="_blanks" href=""><img src="<?php echo $row['image'] ?>" class="img-responsive"></a>
						                    <a class="btn btn-w-m btn-success btn-sm" href="https://www.facebook.com/<?php echo $row['id_post'] ?>" target="_blank"><i class="fa fa-external-link" aria-hidden="true"></i> Xem Thêm</a>
						                    <a class="btn btn-w-m btn-danger btn-sm" href="#" disabled=""><?php echo $row['reactions'] ?> Likes <i class="fa fa-heart" aria-hidden="true"></i></a>
						                    <a class="btn btn-w-m btn-warning btn-sm" href="#" disabled=""><?php echo $row['comments'] ?> Comments</a>
						                    <a class="btn btn-w-m btn-success btn-sm " href="#" disabled=""><?php echo $row['created_time'] ?> </a>
                                          </div>
                                        </div>
                                       
                       </div>
<?		}
		}else {
			echo 'Không có kết quả nào cho từ khóa :"'.$_GET['keyword'].'"';
		}
	}
	}else {
		echo 'Không có từ khóa nào được gởi đến.';
	}




?>