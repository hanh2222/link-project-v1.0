        <div id="page-wrapper" class="gray-bg dashbard-1">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>

        </div>
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <?php if(!empty($administrator or $moderator)){ echo '<span class="m-r-sm text-muted welcome-message">Chào mừng Chủ nhân đã tới '.$groupname.'. :V đừng Hấp Diêm tôi nha :P</span>'; } else {   echo '<span class="m-r-sm text-muted welcome-message">Chào mừng bạn tới '.$groupname.'.</span>';} ?>
                </li>
                


                <li>
                    <a href="/logout.php">
                        <i class="fa fa-sign-out"></i> Đăng xuất
                    </a>
                </li>
               
            </ul>

        </nav>
        </div>
                <div class="row m-b-lg m-t-lg ">
                <div class="col-md-6">

                    <div class="profile-image">
                        <img src="https://graph.facebook.com/<?=$idreals?>/picture?width=128" class="img-circle circle-border m-b-md" alt="profile">
                    </div>
                    <div class="profile-info">
                        <div class="">
                            <div>
                                <h2 class="no-margins">
                                    
                                </h2>
                                 <?php if(!empty($administrator or $moderator)){ echo '<h4>Chào ADMIN <strong><a href="https://fb.com/'.$idreals.'" target="_blank">'.$profile['name'].'</a></strong></h4> <small>Chúc BOSS Tham Quan Vui Vẽ<br> ahihi.</small>'; } else {   echo '<h4>Chào Bạn <strong><a href="https://fb.com/'.$idreals.'" target="_blank">'.$name.'</a></strong></h4> <small>Bạn đã và đang là thành viên của Team '.$groupname.'<br> Hãy cũng phát triển Team bạn nhé.</small>';} ?>
                            </div>
                        </div>
                    </div>
                </div>