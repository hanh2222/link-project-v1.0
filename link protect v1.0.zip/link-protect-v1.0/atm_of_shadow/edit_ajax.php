<?php
/* >_ Developed by Vy Nghia */
require_once '../server/config.php';
require_once '../login.php';

#Hash & Link
$ConditonNumber = rand(1,2);
$hash1 = rand(100, 1000);
$hash2 = rand(1, 1000);
$hash3 = rand(1, 1000);

//Text radnom Generator
function _u31ato($i = 1) {
	return substr(str_shuffle(str_repeat($x='xsz', ceil($i/strlen($x)) )),1,$i);
}
$StrHash1 = _u31ato();
if($ConditonNumber == 1){
function _x3w5sj($i = 1) {
	return substr(str_shuffle(str_repeat($x='xsz', ceil($i/strlen($x)) )),1,$i);
}
$StrHash2 = _x3w5sj();
}

$PostVerifyID = $_POST['PostVerifyID'];
$TargetID = $groupid;
$SaveMode = $_POST['SaveMode'];
$MainURL = $_POST['url'];
$like= $_REQUEST['like'];
$comment= $_REQUEST['comment'];
$idhashtag = $_POST['idhashtag'];
$Password = $_POST['password']; //Set Password

# TimeZone/Time
date_default_timezone_set('Asia/Ho_Chi_Minh'); //TimeZone VietNam
$time = date("Y-m-d h:i:s"); //Time type

if(isset($MainURL)&&!empty($MainURL)){
# Short URL	

//Print result
echo '<div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Kết quả </h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>

                           
                        </div>
                    </div>
                    <div class="ibox-content" id="results">
                    <div class="alert alert-info" style="color:blue" role="alert">
                        <strong>*Lưu ý:</strong><br>
                        
                        - Copy cả link và hashtag để đăng bài.<br>
                        - Khi đã đăng bài xong . Vui lòng chờ trong vòng 5 phút.<br>
                        - Nếu trong vòng 5 phút nếu chưa kích hoạt, vui lòng vào trang ẩn link của bạn để kích hoạt <br>
                            
                    
                </div>


                    <label for="link-and-hash">Link khóa kèm hashtag (copy toàn bộ vào bài đăng nhé):</label><br>
                    <div class="input-group">
                        <input id="short-url" class="form-control" value="'.$GoogleShortUrl.' | #protect@'.$Hashtag.'@" readonly=""><br>
                        <span class="input-group-btn">
                            <button id="generator-url" data-clipboard-target="#short-url" data-clipboard-target="#short-url" class="btn btn-info btn-fill">Sao Chép</button>';

#Insert data url into SQL
//mysql_query("INSERT INTO `protect`(`id`, `facebook_user_id`, `group_id`,`post_id`, `hash`, `url`, `short_url`, `password`, `like`, `comment`, `time`) VALUES ('','$userID', '$TargetID', '', '$HashURL', '$MainURL', '$GoogleShortUrl', '$Password', '$like', '$comment', '$time')");
#Insert data url into SQL
//mysql_query("UPDATE `protect` SET `id`='$idhashtag',`facebook_user_id`='$userID',`group_id`='$TargetID',`url`='$MainURL',`password`='$Password',`like`='$like',`comment`='$comment',`time`='$time' WHERE 1");
}
mysql_query("UPDATE `protect` SET `url` = '$MainURL' WHERE `protect`.`id` = '$idhashtag'");
mysql_query("UPDATE `protect` SET `password` = '$Password' WHERE `protect`.`id` = '$idhashtag'");
mysql_query("UPDATE `protect` SET `like` = '$like' WHERE `protect`.`id` = '$idhashtag'");
mysql_query("UPDATE `protect` SET `comment` = '$comment' WHERE `protect`.`id` = '$idhashtag'");
mysql_query("UPDATE `protect` SET `time` = '$time' WHERE `protect`.`id` = '$idhashtag'");
if($_GET['act']=='SaveID'){
	if(!empty($TargetID)){
		$GroupApi = 'https://graph.facebook.com/v2.10/'.$TargetID.'/?access_token='.$accessToken;
		$CheckGroup = json_decode(file_get_contents($GroupApi));
		
		$Privacy = $CheckGroup->privacy;
		
		if(!$Privacy){
			header('HTTP/1.0 404 Not Found');
			exit;
		}
		$CheckSaveID = mysql_query("SELECT * FROM `saved` WHERE `user_id` = '$userID' AND `target_id` = '$TargetID'");
		if(mysql_fetch_array($CheckSaveID) == null){
			mysql_query("INSERT INTO `saved`(`id`, `user_id`, `target_id`, `post_verify`) VALUES ('', '$userID','$TargetID','')");
		}
	}
}

if($_GET['act']=='Verify'){
	if(!empty($PostVerifyID)){
		$GroupApi = 'https://graph.facebook.com/v2.10/'.$TargetID.'/?access_token='.$accessToken;
		$CheckGroup = json_decode(file_get_contents($GroupApi));
		
		$Privacy = $CheckGroup->privacy;
		
		if(!$Privacy){
			header('HTTP/1.0 404 Not Found');
			exit;
		}
		
		$PostApi = 'https://graph.facebook.com/v2.10/'.$PostVerifyID.'/?fields=id,to&access_token='.$accessToken;
		$CheckPost = json_decode(file_get_contents($GroupApi));
		
		$PostID = $CheckPost->id;
		
		if(!$PostID){
			header('HTTP/1.0 404 Not Found');
			exit;
		}
		
		$AdminGroupApi = 'https://graph.facebook.com/v2.10/'.$TargetID.'/?fields=admins,moderators&litmit=50&access_token='.$accessToken;
		$CheckAdmin = json_decode(file_get_contents($AdminGroupApi));
		
		$AdminList = $CheckAdmin->admins;
		
		$ModList = $CheckAdmin->moderators;
		
		foreach($AdminList->data as $admin){
			if($admin->id == $userID){
	        $administrator = true;
	    	}
		}
		
		foreach($ModList->data as $mod){
			if($mod->id == $userID){
			$moderator = true;
			}
		}
		
		if(!empty($administrator or $moderator)){
			$Permission = 'ok';
		} else {
			$Permission = null;
		}
		
		$CheckSaveID = mysql_query("SELECT * FROM `saved` WHERE `target_id` = '$TargetID'");
		if(mysql_fetch_array($CheckSaveID) !== false){
			if(!empty($Permission)){
				 mysql_query("UPDATE `".$dbname."`.`saved` SET `post_verify` = '$PostVerifyID' WHERE `saved`.`target_id` = '$TargetID'");
				} else {
					header('HTTP/1.0 403 Permission Denied');
				}
			} else {
			//User no have in mySQL
			mysql_query("INSERT INTO `saved`(`id, ``user_id`, `target_id`, `post_verify`) VALUES ('', '$userID','$TargetID','$PostVerifyID')");
		}
	}
}

if($_GET['act'] == 'DeleteID'){
	if(!empty($_POST['GroupSavedID'])){
		mysql_query("DELETE FROM `".$dbname."`.`saved` WHERE `saved`.`target_id` = '".$_POST['GroupSavedID']."'");
	}
}
