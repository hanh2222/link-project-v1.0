<?php
	if(isset($accessToken)){
		if(isset($password)){
		  echo '<li><input type="checkbox" value="" name="" class="i-checks" checked ><span class="m-l-xs">Mật khẩu bảo vệ</span><small class="label label-danger"><i class="fa fa-key"></i> OK</small></li>';
		} else {
		  echo ' <li><input type="checkbox" value="" name="" class="i-checks" disabled ><span class="m-l-xs">Mật khẩu bảo vệ</span><li><form method="POST" class="input-group"><input type="text" type="password" name="password"  class="form-control" placeholder="Nhập mật khẩu bảo vệ..."><span class="input-group-btn"> <button type="submit" class="btn btn-primary"><i class="fa fa-unlock" ></i> Mở Khóa</button> </span></form></li>';
		}
		if(isset($liked)){
		    
		  echo '<li><input type="checkbox" value="" name="" class="i-checks"  checked ><span class="m-l-xs">Phải thể hiện cảm xúc cho bài viết.</span><small class="label label-info"><i class="fa fa-cog"></i> OK</small></li>';
		} else {
		  echo '<li><input type="checkbox" value="" name="" class="i-checks"  disabled ><span class="m-l-xs">Phải thể hiện cảm xúc cho bài viết.</span></li>';
		}
		if(isset($commented)){
		  echo '<li><input type="checkbox" value="" name="" class="i-checks" checked ><span class="m-l-xs">Phải bình luận cho bài viết</span><small class="label label-warning"><i class="fa fa-bolt"></i> OK</small></li>';
		} else {
		  echo '<li><input type="checkbox" value="" name="" class="i-checks" disabled ><span class="m-l-xs">Phải bình luận cho bài viết</span></li>';
		}
		if(isset($joined)){
		  echo '<li><input type="checkbox" value="" name="" class="i-checks" checked ><span class="m-l-xs">Khóa Thành viên.</span><small class="label label-primary"><i class="fa fa-send"></i> OK</small></li>';
		} else {
		echo '<li><input type="checkbox" value="" name="" class="i-checks"  ><span class="m-l-xs">Khóa Thành viên.</span></li>';

		}
	}
?>

	