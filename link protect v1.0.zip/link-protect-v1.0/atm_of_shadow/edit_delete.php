<?php
/* >_ Developed by Vy Nghia */
require_once '../login.php';
$idhashtag = $_POST['idhashtag'];
mysql_query("DELETE FROM `protect` WHERE `id` = '$idhashtag'");