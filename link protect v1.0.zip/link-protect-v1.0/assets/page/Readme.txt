﻿Link Protect (v3.0.1) cho Trang - Miễn phí! (đã được cải thiện so với phiên bản trước)

[Hướng dẫn]
1. Vào developers.facebook.com và console.cloud.google.com để tạo/nhận App ID & App Secret (Facebook) và Short URL Api Key (Google)

2. Import (Nhập) file Link Protect.sql vào phpmyadmin. Tiếp theo http://domain.com/install (mặc định mật khẩu truy: Dung Ki Thi Gay) cập để cấu hình cho đúng với các dữ liệu.

3. Vào http://domain.com/_system/admin điền
Tài khoản: vynghia
Mật khẩu: nghiabestgay2k2
Ở trên trang có các mục đích để bạn lựa chọn [Thông tin quản trị/Quản lý liên kết/Tạo liên kết/Đăng xuất]

---
Tác giả: Vy Nghĩa (Nghia is Gay)
Fanpage: https://www.facebook.com/NghiaisGay
---

(c) 2017 Vy Nghia
Chịu trách nghiệm bởi Vy Nghĩa.
