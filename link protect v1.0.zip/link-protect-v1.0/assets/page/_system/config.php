<?php
/* >_ Developed by Vy Nghia */
require 'class/ProtectClass.php';

//default config
define('PAGEID', '123456789');
define('WEBURL', 'http://page.topgunny.com');

$db = new Database;
$db->dbhost('localhost');
$db->dbuser('topgunny_page');
$db->dbpass('topgunny_page');
$db->dbname('topgunny_page');

$db->connect();

//Facebook App
$FacebookAppID = '1942298935785668';
$FacebookAppSecret = 'cde2e0fafc0e522f693f7117f488f7cc';

//Google Api
$GoogleApiKey = 'AIzaSyAlFMWpH9CPaRCJwiA4OTHfCwxgWJ1lpMg';