<?php
class Database
{
	protected $dbhost;
	protected $dbuser;
	protected $dbpass;
	protected $dbname;
	
	public function dbhost($dbhost){
		$this->dbhost = $dbhost;
	}
	
	public function dbuser($dbuser){
		$this->dbuser = $dbuser;
	}
	
	public function dbpass($dbpass){
		$this->dbpass = $dbpass;
	}
	
	public function dbname($dbname){
		$this->dbname = $dbname;
	}
	
	public function connect(){
		$con = @mysql_connect($this->dbhost, $this->dbuser, $this->dbpass);
		@mysql_query("SET character_set_results=utf8", $con);
		@mb_language('uni'); 
		@mb_internal_encoding('UTF-8');
		@mysql_select_db($this->dbname, $con);
		@mysql_query("set names 'utf8'",$con);
	}
	
	public function dbinfo($db){
		echo $this->$db;
	}
}
class Protect
{
    public function curl($url){
    	$curl = curl_init();
    	curl_setopt_array($curl, array(
    	    CURLOPT_URL => $url,
		    CURLOPT_RETURNTRANSFER => true,
	    	CURLOPT_TIMEOUT => 0,
    	    CURLOPT_SSL_VERIFYPEER => false,
    	    CURLOPT_SSL_VERIFYHOST => false
    	));
    	$response = curl_exec($curl);
    	curl_close($curl);
    	$response = json_decode($response,JSON_UNESCAPED_UNICODE);
    	return $response;
    	$this->curl = $url;
    }
	public $id;
	public function setCreatorID($userID){
		$this->id = $userID;
	}
	public function fetchHash($Hashs){
		global $sql, $AuthorID, $imageshare, $GroupID, $hashtag, $PostID, $countlike, $countcmt, $url, $likeds, $commenteds, $join, $ProtectPassword, $time, $idhashtag, $short_url;
		$Select = mysql_query("SELECT * FROM `protect` WHERE `hash` = '$Hashs'");
		$sql = mysql_fetch_array($Select);
		$idhashtag = $sql['id'];
		$AuthorID = $sql['facebook_user_id'];
		$imageshare = $sql['image'];
		$GroupID = $sql['group_id'];
		$hashtag = $sql['hash'];
		$PostID = $sql['post_id'];
		$countlike = $sql['countlike'];
		$countcmt = $sql['countcmt'];
		$url = $sql['url'];
		$short_url = $sql['short_url'];
		$likeds = $sql['like'];
		$commenteds =$sql['comment'];
		$join =$sql['joined'];
		$ProtectPassword = $sql['password'];
		$time = $sql['time'];
	}
	public function loghashcallback($Hashs){
	    $callback = fopen("logcallback/".$_SERVER['REMOTE_ADDR'].".txt", "w") or die("Unable to open file!");
	    fwrite($callback, "v/".$Hashs."");
	    fclose($callback);
	}
	public function Checklike_comment($Group_ID, $tokens, $hashtag, $ID, $checklike, $checkcomment){
	    global $FeedJson, $FoundPostID, $FoundPost, $liked, $commented, $idpost;
	    $FeedJson = $this->curl('https://graph.facebook.com/'.$Group_ID.'/feed?fields=id,message&limit=100&access_token='.$tokens);
	    foreach($FeedJson['data'] as $feed) {
	        if(strpos($feed['message'], $hashtag) !== FALSE) {
	            $FoundPost = true;
	            $FoundPostID = str_replace($Group_ID.'_', '',$feed['id']);
	            $idpost = $feed['id'];
	            if(isset($FoundPostID)){
	                if($checklike == null){
	                    $liked = true;
	                } else {
	                    $LikeApi = 'https://graph.facebook.com/v2.10/'.$idpost.'/reactions?fields=id&pretty=0&live_filter=no_filter&limit=5000&access_token='.$tokens;
	                    $LikeApi_decode = $this->curl($LikeApi);
	                    foreach($LikeApi_decode['data'] as $like){
	                        if($like['id'] == $ID){
	                            $liked = true;
	                        }
	                    }
	                }
	                if($checkcomment == null){
	                    $commented = true;
	                } else {
	                    $CmtApi = 'https://graph.facebook.com/v2.10/'.$idpost.'/comments?fields=from,id&limit=5000&access_token='.$tokens;
	                    $CmtApi_decode = $this->curl($CmtApi);
	                    foreach($CmtApi_decode['data'] as $cmt){
	                        if($cmt['from']['id'] == $ID){
	                            $commented = true;
	                        }
	                    }
	                }
	            }
	        }
	    }
	    
	}
	public function checkmember($Group_ID, $id, $tokens, $checkjoin){
	    global $joined;
        if($checkjoin == null){
            $joined = true;
        } else {
            $MemberApi = 'https://graph.facebook.com/fql?q=SELECT%20uid%20FROM%20group_member%20WHERE%20gid='.$Group_ID.'%20AND%20uid='.$id.'&access_token='.$tokens;
            $MemberApi_decode = $this->curl($MemberApi);
            foreach($MemberApi_decode['data'] as $member){
                if($member['uid'] == $id){
                    $joined = true;
                }
            }
        }
	}
	public function countlikecmt($id_post, $tokens){
	    global $solike, $socmt;
	    if(isset($id_post)){
	        $searchpost = "https://graph.facebook.com/v2.10/".$id_post."?fields=shares,reactions.summary(true),comments.summary(true)&access_token=".$tokens.""; 
	        $likecmtcount = $this->curl($searchpost); 
	        $solike = $likecmtcount['reactions']['summary']['total_count'];
	        $socmt = $likecmtcount['comments']['count'];
	    }
	}
}
class website
{
    public function curl($url){
    	$curl = curl_init();
    	curl_setopt_array($curl, array(
    	    CURLOPT_URL => $url,
		    CURLOPT_RETURNTRANSFER => true,
	    	CURLOPT_TIMEOUT => 0,
    	    CURLOPT_SSL_VERIFYPEER => false,
    	    CURLOPT_SSL_VERIFYHOST => false
    	));
    	$response = curl_exec($curl);
    	curl_close($curl);
    	$response = json_decode($response,JSON_UNESCAPED_UNICODE);
    	return $response;
    	$this->curl = $url;
    }
    public function autosetupgroup($id,$acc_token){
        $resultadmingroup = mysql_query("SELECT `id` FROM `admingroup` where 1");
        $countadmingroup=mysql_num_rows($resultadmingroup);
        if($countadmingroup==0){
            $api = $this->curl('https://graph.facebook.com/v2.10/'.$id.'/?fields=admins,moderators&litmit=50&access_token='.$acc_token);
            foreach($api['admins']['data'] as $admin){
                $adminid = $admin['id'];
                $adminname = $admin['name'];
                mysql_query("INSERT INTO `admingroup`(`id`, `name`, `function`) VALUES ('$adminid','$adminname','admin')");
            }
            foreach($api['moderators']['data'] as $mod){
                $modid = $mod['id'];
                $modname = $mod['name'];
                mysql_query("INSERT INTO `admingroup`(`id`, `name`, `function`) VALUES ('$modid','$modname','mod')");
            }
        }
        $resultgroupname = mysql_query("SELECT `name` FROM `groupname` WHERE 1");
        $countgroupname=mysql_num_rows($resultgroupname);
        if($countgroupname==0){
            $groupApi = $this->curl('https://graph.facebook.com/'.$id.'?access_token='.$acc_token);
            $groupname = $groupApi['name'];
            mysql_query("INSERT INTO `groupname`(`name`, `id`) VALUES ('$groupname','$id')");
        }
        
    }
    public function getuser($ids){
        global $name, $id, $idreals, $image;
    	$DataUser = mysql_query("SELECT * FROM `user` WHERE `id` = '$ids'"); //Check user exists in SQL
    	$facebookname = mysql_fetch_array($DataUser);
        $name = $facebookname['name'];
        $id = $facebookname['id'];
        $idreals = $facebookname['idreal'];
        $image = $facebookname['image'];
    }
    public function updatename($tenfb, $tendata, $ids){
        if($tenfb == $tendata){
            null;
        }
        else{
            mysql_query("UPDATE `user` SET `name`='$tenfb' WHERE id = '$ids'");
        }
    }
    public function getidreal($idrealx,$ids,$token){
        global $idreal, $imagefbbase64;
        if($idrealx == null){
            $linkApi = 'https://graph.facebook.com/'.$ids.'?access_token='.$token;
            $link = $this->curl($linkApi);
            $usName = $link['username']; 
            $ProfileApis = 'https://graph.facebook.com/'.$usName.'?fields=id,link&access_token='.$token;
            $users = $this->curl($ProfileApis);
            $idreal =$users['id'];
            if(empty($usName))
            $linkname = $link['link'];
            $ProfileApis = 'https://graph.facebook.com/'.$linkname.'&access_token='.$token;
            $users = $this->curl($ProfileApis);
            $idreal .=$users['id'];
//            $imagefb = "https://graph.facebook.com/$idreal/picture?width=64&access_token=$token";
//            $imagefbbase64 = base64_encode(file_get_contents($imagefb));
        }
    }
    public function getgroup($idgroup){
        global $groupname, $groupid;
        $groups = mysql_query("SELECT `name`, `id` FROM `groupname` WHERE id = '$idgroup'");
        $group = mysql_fetch_array($groups);
        $groupname = $group['name'];
        $groupid = $group['id'];
    }
}