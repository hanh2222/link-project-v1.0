<?php
/* FACEBOOK website */
$FacebookAppID = '{FB_APP_ID}';
$FacebookAppSecret = '{FB_APP_SR}';
define('access_token', '{access_token}');
define('GroupID', '{group}');
