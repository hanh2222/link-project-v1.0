<?php
/* >_ Developed by Vy Nghia */
header('Content-Type: text/html; charset=utf-8');
require 'lib/class/protect_class.php';

/* WEBSITE DOMAIN */
define('WEBURL', '{1}');
$domain = WEBURL;

/* MYSQL DATABASE */
$db = new Database;
$db->dbhost('{2}');
$db->dbuser('{3}');
$db->dbpass('{4}');
$db->dbname('{5}');

$db->connect();

/* CALL APP SDK */
include ('api.php');