<?php
/* CREATE ADMIN GROUP TABLE */
mysql_query("CREATE TABLE `admingroup` (
  `id` bigint(20) NOT NULL,
  `name` text CHARACTER SET utf8 NOT NULL,
  `function` text CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;");
/* INSERT TO ADMIN TABLE */
mysql_query("INSERT INTO `admingroup` (`id`, `name`, `function`) VALUES
(100012085296978, 'Tiêu Phong', 'admin');");
/* CREATE GROUP NAME TABLE */
mysql_query("CREATE TABLE `groupname` (
  `name` text CHARACTER SET utf8 NOT NULL,
  `id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;");

/* CREATE Project TABLE */
mysql_query("CREATE TABLE `protect` (
  `id` bigint(20) NOT NULL,
  `facebook_user_id` bigint(20) NOT NULL,
  `image` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `group_id` text CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `post_id` text COLLATE latin1_german1_ci NOT NULL,
  `countlike` text COLLATE latin1_german1_ci NOT NULL,
  `countcmt` text COLLATE latin1_german1_ci NOT NULL,
  `hash` text COLLATE latin1_german1_ci NOT NULL,
  `url` text CHARACTER SET utf8 NOT NULL,
  `short_url` text COLLATE latin1_german1_ci NOT NULL,
  `password` text COLLATE latin1_german1_ci NOT NULL,
  `like` text COLLATE latin1_german1_ci NOT NULL,
  `comment` text COLLATE latin1_german1_ci NOT NULL,
  `time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;");
/* CREATE USER TABLE */
mysql_query("CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `idreal` bigint(20) NOT NULL,
  `name` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `image` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `hash_verify` text COLLATE latin1_german1_ci NOT NULL,
  `banned` text COLLATE latin1_german1_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;");
/* SET `id` IS PRIMARY KEY FOR admingroup TABLE */
mysql_query("ALTER TABLE `admingroup`
  ADD PRIMARY KEY (`id`);");
mysql_query("ALTER TABLE `groupname`
  ADD PRIMARY KEY (`id`);");
mysql_query("ALTER TABLE `protect`
  ADD PRIMARY KEY (`id`);");
mysql_query("ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);");
/* SET AUTO_INCREMENT FOR POST TABLE */
mysql_query("ALTER TABLE `protect`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=382494142163555;
COMMIT;");
  
  /* CHECK MYSQL */  
if(mysql_error())
	echo mysql_error();
else
	echo (true);