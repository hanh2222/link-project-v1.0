-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th5 27, 2018 lúc 07:18 PM
-- Phiên bản máy phục vụ: 5.6.39
-- Phiên bản PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `nickxyz_anlink`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `admingroup`
--

CREATE TABLE `admingroup` (
  `id` bigint(20) NOT NULL,
  `name` text CHARACTER SET utf8 NOT NULL,
  `function` text CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `groupname`
--

CREATE TABLE `groupname` (
  `name` text CHARACTER SET utf8 NOT NULL,
  `id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `protect`
--

CREATE TABLE `protect` (
  `id` bigint(20) NOT NULL,
  `facebook_user_id` bigint(20) NOT NULL,
  `image` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `group_id` text CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `post_id` text COLLATE latin1_german1_ci NOT NULL,
  `countlike` text COLLATE latin1_german1_ci NOT NULL,
  `countcmt` text COLLATE latin1_german1_ci NOT NULL,
  `hash` text COLLATE latin1_german1_ci NOT NULL,
  `url` text CHARACTER SET utf8 NOT NULL,
  `short_url` text COLLATE latin1_german1_ci NOT NULL,
  `password` text COLLATE latin1_german1_ci NOT NULL,
  `like` text COLLATE latin1_german1_ci NOT NULL,
  `comment` text COLLATE latin1_german1_ci NOT NULL,
  `joined` text COLLATE latin1_german1_ci NOT NULL,
  `time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `idreal` bigint(20) NOT NULL,
  `name` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `admingroup`
--
ALTER TABLE `admingroup`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `groupname`
--
ALTER TABLE `groupname`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `protect`
--
ALTER TABLE `protect`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `protect`
--
ALTER TABLE `protect`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=382494142163573;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
