<?php
/* >_ Developed by Vy Nghia */
require '../login.php';
error_reporting(0);
switch($_GET['do']){
	/* SQL */
	case 'install':
		if(isset($_SESSION['install'])){
			if($_GET['type'] == 'mysql')
				include ('lib/data/mysql/install/database.install.php');
		}
		break;
}