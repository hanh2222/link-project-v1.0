<?php
/* >_ Developed by Vy Nghia */
header('Content-Type: text/html; charset=utf-8');
require 'lib/class/protect_class.php';

/* WEBSITE DOMAIN */
define('WEBURL', 'https://tristana-bot.xyz');
$domain = WEBURL;

/* MYSQL DATABASE */
$db = new Database;
$db->dbhost('localhost');
$db->dbuser('nickxyz_anlink');
$db->dbpass('nickxyz_anlink');
$db->dbname('nickxyz_anlink');

$db->connect();

/* CALL APP SDK */
include ('api.php');